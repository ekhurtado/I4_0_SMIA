export TURTLEBOT3_MODEL=burger
# Inicializar simulador Gazebo con instancia del turtlebot3
roslaunch turtlebot3_gazebo turtlebot3_world.launch
