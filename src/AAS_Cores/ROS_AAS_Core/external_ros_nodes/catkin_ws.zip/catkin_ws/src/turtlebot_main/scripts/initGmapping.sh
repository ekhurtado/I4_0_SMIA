export TURTLEBOT3_MODEL=waffle_pi

# Inicializar el nodo encargado de SLAM (Creacion de mapa)
roslaunch turtlebot3_slam turtlebot3_slam.launch slam_methods:=gmapping
