#!/usr/bin/env python
# license removed for brevity
import random
import time

import actionlib
import rospy
from geometry_msgs.msg import PoseStamped
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
#from turtlebot_main.msg import Coordinate
from std_msgs.msg import String
from twisted.positioning.base import Coordinate


# Este fichero simula la petición de servicio desde TransportAgent. Se publica una coordenada (aleatoria)
# que será la meta/objetivo del turtlebot
def talker():

    def movebase_client(goal_x, goal_y):

        # Crear un nodo "action client" llamado 'move_base' con el action definition file (ADF) "MoveBaseAction"
        client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        rospy.init_node('move_base')
        # Queda a la espera de que el action server se haya iniciado y esté a la escucha de goals (objetivos)
        client.wait_for_server()

        # Crea un nuevo goal con el constructor de MoveBaseGoal
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()

        # Indicar las coordenadas (X,Y)
        goal.target_pose.pose.position.x = float(goal_x)
        goal.target_pose.pose.position.y = float(goal_y)

        # Rotación, para que el robot mire de frente al almacen
        goal.target_pose.pose.orientation.w = 1.0

        time.sleep(5)
        # Envía el goal al action server
        client.send_goal(goal)
        # QUeda a la espera de que el servidor termine de procesar la solicitud
        wait = client.wait_for_result()

        # Si no hay respuesta, se asume que el servidor no está disponible o hay algún error
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
        else:
            # Devuelve el resultado de la operación
            return client.get_result()

    move_base_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=5)
    # Publica el estadp actual del recurso transporte

    # Extrae los datos del rosbag anterior

    print("** ROS Navigation test from PYTHON client **")
    goal_x = "1.658"
    goal_y = "2.123"

    try:


        # Se inicia nuevamente un nodo rospy para que publique el SImpleActionClient
        result = movebase_client(goal_x, goal_y)

        # Si ha habido resultado
        if result:
            rospy.loginfo("Goal execution done!")

    except rospy.ROSInterruptException:
        # Si ha habido algún error
        rospy.loginfo("Navigation test finished.")





if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass