export TURTLEBOT3_MODEL=burger
# Inicializar simulador Gazebo con instancia del turtlebot3
roslaunch turtlebot_main turtlebot_main.launch

