#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import String
import roslaunch

def GWAgentROSNode():

    # Definimos un nodo publisher, que publicará datos en el tópico 'coordinate'
    pub = rospy.Publisher('/coordinateIDLE', String, queue_size=10)

    # El nodo se reconocerá por el nombre 'GW_ROS_NODE'
    rospy.init_node('GW_ROS_NODE', anonymous=True)

    if not rospy.is_shutdown():
        rospy.loginfo( "GW_ROS_NODE sending data to MAIN_NODE")
        data = input("TYPE 'GO' TO SEND DATA:")

        if (data == "GO"):
            pub.publish(data)
        else:
            pub.publish("STOP")

if __name__ == '__main__':
    try:
        GWAgentROSNode()
    except rospy.ROSInterruptException:
        pass