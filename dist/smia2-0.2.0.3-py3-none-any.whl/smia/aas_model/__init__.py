"""This module contains the extended model of Basyx Python SDK. This model is extended defining new methods for some
classes."""