"""
This package includes all possible behaviours of AAS Manager SPADE agents.
"""