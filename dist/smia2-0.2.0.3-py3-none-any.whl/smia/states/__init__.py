"""
This package includes the classes of all possible states of the AAS Manager SPADE agents.
"""