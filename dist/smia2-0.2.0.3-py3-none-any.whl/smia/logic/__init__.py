"""
This package contains all utilities related to the internal logic of the AAS Manager.
"""