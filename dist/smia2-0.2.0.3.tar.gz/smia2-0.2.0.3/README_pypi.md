# Self-configurable Manufacturing Industrial Agent: SMIA 

[![Docker badge](https://img.shields.io/docker/pulls/ekhurtado/aas-manager.svg)](https://hub.docker.com/r/ekhurtado/aas-manager/) ![GitHub release (latest SemVer)](https://img.shields.io/github/v/release/ekhurtado/I4_0_SMIA?sort=semver) [![Codacy Badge](https://app.codacy.com/project/badge/Grade/e87506fff1bb4a438c20e11bb7295f51)](https://app.codacy.com/gh/ekhurtado/I4_0_SMIA/dashboard?utm_source=gh&utm_medium=referral&utm_content=&utm_campaign=Badge_grade) [![Documentation Status](https://readthedocs.org/projects/i4-0-smia/badge/?version=latest)](https://i4-0-smia.readthedocs.io/en/latest/)

![SMIA Logo](https://raw.githubusercontent.com/ekhurtado/I4_0_SMIA/refs/heads/main/images/I4_0_SMIA_logo_positive.png "SMIA main logo")

[//]: # (The logo image need to be obtained externally)

[//]: # (//Dependiendo del modo de GitHub oscuro o claro se añade una imagen u otra&#41;)

The Self-configurable Manufacturing Industrial Agent (SMIA) is a proposal for the implementation of the concept of the I4.0 Component from the Reference Architectural Model Industrie 4.0 (RAMI 4.0) as an AAS-compliant agent-based Digital Twin (DT). The features of the SMIA approach include:

- free & open-source
- AAS-compliant: standardized approach
- Ontology-based
- easily customizable and configurable
- self-configuration at software startup
- easy to usage
- containerized solution

> 💡 **TIP:**
> For more details on Self-configurable Manufacturing Industrial Agent (SMIA) see the [📄 **full documentation**](https://i4-0-smia.readthedocs.io/en/latest/).

## Usage

> ❗ **IMPORTANT:**
> At the moment there is no final version available for the SMIA.
> The project is currently under development.
> Therefore, SMIA is not a ready-to-use implementation.
> New features and bug fixes will be uploaded during development.
 
Multiple ways of running SMIA software are available. The associated GitHub repository shows how to run the base SMIA software.

In this case, how to use the SMIA Python package is shown.

### Installation

The SMIA approach can be easily installed using [pip](https://pip.pypa.io/en/stable/):

```
pip install smia
```
[//]: # (TODO actualizar con el nombre cuando se publique)

### Available facilities

The SMIA approach offers different facilities for its use:

- ``smia.launchers``: Some launchers to run the base SMIA software.
- ``smia.agents``: The Agent classes available to be instantiated and used.
- ``smia.assetconnection``: Tools related to connection with assets.

[//]: # (TODO actualizar con los que se presenten)

### Examples

Create and run an ``SMIAAgent``:
```python
import smia
from smia.agents.extendible_agent import ExtendibleAgent  # Import from the SMIA package

extendible_agent = ExtendibleAgent()
smia.run(extendible_agent)
```

Load an ``AAS model`` to ``SMIAAgent``:
```python
import smia

smia.load_aas_model('<path to the AAS model>')
```

Add new ``Agent Capability`` to ``SMIAAgent``:
```python
from smia.agents.extendible_agent import ExtendibleAgent  # Import from the SMIA package

new_capability = spade.behaviour
extendible_agent.add_agent_capability(new_capability)
```

Add new ``Agent Service`` to ``SMIAAgent``:
```python
from smia.agents.extendible_agent import ExtendibleAgent  # Import from the SMIA package

extendible_agent.add_agent_service(new_service_method)
```

#### Complete example

```python
import smia
import asyncio
from spade.behaviour import CyclicBehaviour
from smia.agents.extendible_agent import ExtendibleAgent  # Import from the SMIA package

class MyBehaviour(CyclicBehaviour):

    async def on_start(self):
        print("MyBehaviour started")
        self.iteration = 0

    async def run(self):
        print("MyBehaviour is in iteration {}.".format(self.iteration))
        self.iteration += 1
        await asyncio.sleep(2)

def new_service_method():
    print("This is a new service to be added to SMIA.")
    
def main():
    extendible_agent = ExtendibleAgent()
    smia.load_aas_model('<path to the AAS model>')
    
    extendible_agent.add_agent_capability(MyBehaviour)
    extendible_agent.add_agent_service(new_service_method)
    
    smia.run(extendible_agent)

if __name__ == '__main__':
    main()
```

## Dependencies

The SMIA software requires the following Python packages to be installed to run correctly. These dependencies are listed in ``setup.py`` so that they are automatically obtained when installing with ``pip``:

- ``spade`` (MIT license)
- ``basyx-python-sdk`` (MIT license)
- ``owlready2`` (GNU LGPL licence v3)

[//]: # (TODO actualizar con los que sean)


## License

GNU General Public License v3.0. See `LICENSE` for more information.
