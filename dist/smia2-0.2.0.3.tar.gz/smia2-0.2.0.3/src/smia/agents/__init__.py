"""
This package includes all hierarchy of SPADE agents.
"""