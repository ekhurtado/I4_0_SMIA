"""This module contains the Capability-Skill-Service ontology that is integrated and used in the SMIA approach. In this
module the required classes and methods are stored."""